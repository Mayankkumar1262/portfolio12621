# HTML Basics — Beginner's Guide

A responsive, beginner-friendly website that introduces the fundamentals of HTML through short explanations, code examples, and an interactive three-question quiz.

## Features

- Introduction to HTML and its purpose
- Examples of headings, paragraphs, links, images, lists, and forms
- Explanation of the basic HTML document structure
- Responsive navigation for mobile screens
- Interactive quiz with score feedback
- Accessible labels and reduced-motion support
- No external libraries or build tools required

## Technologies used

- HTML5
- CSS3
- Vanilla JavaScript

## Run the project

1. Download or clone this repository.
2. Open the project folder.
3. Double-click `index.html` to open it in your browser.

You can also use the **Live Server** extension in Visual Studio Code for local development.

## Project structure

```text
html-basics-project/
├── .github/
│   └── ISSUE_TEMPLATE/
│       ├── bug_report.md
│       └── feature_request.md
├── index.html
├── style.css
├── script.js
├── README.md
├── CONTRIBUTING.md
├── LICENSE
└── .gitignore
```

## Learning goals

After exploring this project, a beginner should be able to:

1. Explain what HTML is used for.
2. Recognise common HTML elements and attributes.
3. Identify the main parts of an HTML document.
4. Understand the roles of HTML, CSS, and JavaScript.

## Contributing

Suggestions and improvements are welcome. Please read [CONTRIBUTING.md](CONTRIBUTING.md) and use the issue templates when reporting a bug or suggesting a feature.

## License

This project is available under the MIT License. See [LICENSE](LICENSE).
