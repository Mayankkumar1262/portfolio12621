# Contributing

Thank you for taking an interest in improving HTML Basics!

## How to contribute

1. Fork the repository.
2. Create a branch for your change: `git checkout -b feature/your-change`.
3. Make a focused improvement.
4. Test the page in a browser, including a narrow/mobile viewport.
5. Commit your changes with a clear message.
6. Open a pull request and describe what changed.

## Reporting bugs or requesting features

Use the **Bug report** or **Feature request** template in the GitHub Issues tab. Include clear steps and screenshots when they help explain the problem.

## Code style

- Use semantic HTML elements where appropriate.
- Keep CSS readable and group responsive styles in media queries.
- Use plain JavaScript unless a dependency is genuinely needed.
- Keep keyboard access, labels, and alternative text in mind.
