"use strict";

const menuToggle = document.querySelector("#menuToggle");
const navLinks = document.querySelector("#navLinks");
const quizForm = document.querySelector("#quizForm");
const quizResult = document.querySelector("#quizResult");
const year = document.querySelector("#year");

if (year) {
  year.textContent = String(new Date().getFullYear());
}

if (menuToggle && navLinks) {
  menuToggle.addEventListener("click", () => {
    const isOpen = navLinks.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  });

  navLinks.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      navLinks.classList.remove("open");
      menuToggle.setAttribute("aria-expanded", "false");
      menuToggle.setAttribute("aria-label", "Open navigation");
    });
  });
}

if (quizForm && quizResult) {
  quizForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const answers = { q1: "a", q2: "b", q3: "c" };
    const formData = new FormData(quizForm);
    let score = 0;
    let answered = 0;

    Object.entries(answers).forEach(([question, correctAnswer]) => {
      const selectedAnswer = formData.get(question);
      if (selectedAnswer) answered += 1;
      if (selectedAnswer === correctAnswer) score += 1;
    });

    if (answered < Object.keys(answers).length) {
      quizResult.textContent = "Please answer all 3 questions before checking your score.";
      return;
    }

    quizResult.textContent = `You scored ${score} out of 3. ${score === 3 ? "Excellent work!" : "Keep practising—you are making progress!"}`;
  });
}
