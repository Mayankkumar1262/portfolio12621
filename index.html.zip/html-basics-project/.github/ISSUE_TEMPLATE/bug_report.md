---
name: Bug report
about: Report a problem with the HTML Basics project
title: "[BUG] "
labels: bug
assignees: ""
---

## Describe the bug
A clear description of what is not working.

## Steps to reproduce
1. Open ...
2. Click or enter ...
3. Observe ...

## Expected behaviour
What did you expect to happen?

## Actual behaviour
What happened instead?

## Environment
- Browser:
- Operating system:
- Screen size (if relevant):

## Screenshots
Add screenshots or error messages, if available.
