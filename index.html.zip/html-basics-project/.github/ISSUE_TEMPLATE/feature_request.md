---
name: Feature request
about: Suggest an improvement for the HTML Basics project
title: "[FEATURE] "
labels: enhancement
assignees: ""
---

## Is your feature request related to a problem?
Describe the learning need or difficulty this feature would address.

## Describe the solution
Explain what you would like to see added or changed.

## Additional context
Add examples, sketches, or screenshots if useful.
